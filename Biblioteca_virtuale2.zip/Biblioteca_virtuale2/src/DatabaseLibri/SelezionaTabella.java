package DatabaseLibri;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class SelezionaTabella {
	
	   private Connection connect() {
	        // SQLite connection string
	        Connection conn = null;
	        try {
	            conn = DriverManager.getConnection(Database.DB_URL);
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	        return conn;
	    }
	   
	   

	  /* Visualizzazione su console del database
	   public void view(){
		   String sql = "SELECT * FROM INDIRIZZI";
		   try (Connection conn = this.connect();
		        Statement stmt  = conn.createStatement();
		        ResultSet rs    = stmt.executeQuery(sql)){
			   // stampa i risultati
			   while (rs.next()) 
			   {
					for (int i = 1; i <= 6; i++) 
					{
						System.out.print(rs.getString(i) + " ");
						
					}
					System.out.println();
				}
			   
			   
			   
		        } catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
		    }
		    */
	   
	   public Object[][] fillTable() throws SQLException{
		   Connection conn = this.connect();
		   Object[][] backobj = new Object[100][6];
		   int numRighe= 0;
		   ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM indirizzi");
		   while(rs.next())
		   {
			   backobj[numRighe][0]=rs.getString("ISBN");
			   backobj[numRighe][1]=rs.getString("titolo");
			   backobj[numRighe][2]=rs.getString("autore");
			   backobj[numRighe][3]=rs.getString("quantitadisponibile");
			   backobj[numRighe][4]=rs.getString("genere");
			   backobj[numRighe][5]=rs.getString("annodipubblicazione");
			   
			   numRighe++;
		   }
		  
		   return backobj;
	   }
	   
	   
}
