package GUI;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Classi.Catalogo;
import Classi.Libro;
import DatabaseLibri.Database;
import DatabaseLibri.InserimentoDatabase;
import DatabaseLibri.SelezionaTabella;

import java.time.zone.*;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class GUI_bibliotecaAdmin extends JFrame {

	private JPanel contentPane;
	private JTextField txt_isbn;
	private JTextField txt_titolo;
	private JTextField txt_autore;
	private JTextField txt_qt_disp;
	private JTextField txt_genere;
	private JTextField txt_anno_pub;
	private JTable table;
	private DefaultTableModel tableModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_bibliotecaAdmin frame = new GUI_bibliotecaAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public GUI_bibliotecaAdmin() throws SQLException {

		Object[][] obj;
		Catalogo nuovocatalogo=new Catalogo();
		InserimentoDatabase ins = new InserimentoDatabase();
		SelezionaTabella sel=new SelezionaTabella();
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 483, 359);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 10, 452, 297);
		contentPane.add(tabbedPane);

		JPanel panel = new JPanel();
		tabbedPane.addTab("Consulta Catalogo", null, panel, null);
		panel.setLayout(null);
		
		
		

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Inserisci nuovo Libro", null, panel_1, null);
		panel_1.setLayout(null);
		
		txt_isbn = new JTextField();
		txt_isbn.setBounds(215, 9, 96, 19);
		panel_1.add(txt_isbn);
		txt_isbn.setColumns(10);
		
		txt_titolo = new JTextField();
		txt_titolo.setBounds(215, 42, 96, 19);
		panel_1.add(txt_titolo);
		txt_titolo.setColumns(10);
		
		txt_autore = new JTextField();
		txt_autore.setBounds(215, 74, 96, 19);
		panel_1.add(txt_autore);
		txt_autore.setColumns(10);
		
		txt_qt_disp = new JTextField();
		txt_qt_disp.setBounds(215, 105, 96, 19);
		panel_1.add(txt_qt_disp);
		txt_qt_disp.setColumns(10);
		
		txt_genere = new JTextField();
		txt_genere.setBounds(215, 134, 96, 19);
		panel_1.add(txt_genere);
		txt_genere.setColumns(10);
		
		txt_anno_pub = new JTextField();
		txt_anno_pub.setBounds(215, 163, 96, 19);
		panel_1.add(txt_anno_pub);
		txt_anno_pub.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ISBN");
		lblNewLabel.setBounds(81, 13, 45, 13);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Titolo");
		lblNewLabel_1.setBounds(81, 43, 45, 16);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Autore");
		lblNewLabel_2.setBounds(81, 77, 45, 13);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Quantit\u00E0 disponibile");
		lblNewLabel_3.setBounds(81, 108, 107, 13);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Genere");
		lblNewLabel_4.setBounds(81, 137, 45, 13);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Anno pubblicazione");
		lblNewLabel_5.setBounds(81, 164, 107, 13);
		panel_1.add(lblNewLabel_5);

		
		table = new JTable();
		obj= sel.fillTable();
		
		table.setModel(new DefaultTableModel(
			obj,
			new String[] {
				"ISBN", "Titolo", "Autore", "Quantit\u00E0 disponibile", "Genere", "Anno Pubblicazione"
			}
		));
		
		JButton btn_new_libro = new JButton("Inserisci ");
		//PREMI IL BOTTONE INSERISCI NUOVO LIBRO
		btn_new_libro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Object[][] obj;

			/*
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			 
	        java.util.Date utilDate;
			try {
				utilDate = format.parse(txt_anno_pub.getText());
				java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
				
				
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			*/		
					
			//Inserimento Dati in Tabella
			ins.inserimento(txt_isbn.getText(),txt_titolo.getText(), txt_autore.getText(),Integer.parseInt(txt_qt_disp.getText()),txt_genere.getText(),Integer.parseInt(txt_anno_pub.getText()));
			JOptionPane.showMessageDialog(null, "Inserimento andato bene!");
			        
			try {
				obj=sel.fillTable();
				
				table.setModel(new DefaultTableModel(
					obj,
					new String[] {
						"ISBN", "Titolo", "Autore", "Quantit\u00E0 disponibile", "Genere", "Anno Pubblicazione"
					}
				));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			Libro nuovolibro= new Libro(txt_isbn.getText(),txt_titolo.getText(),txt_autore.getText()
					,Integer.parseInt(txt_qt_disp.getText()),
					txt_genere.getText(),Integer.parseInt(txt_anno_pub.getText()));
			nuovocatalogo.aggiungi_libro(nuovolibro);
//VERIFICARE----------------------------------------
			
			
			Object[] obj1 = { nuovolibro.getISBN(), nuovolibro.getTitolo(), nuovolibro.getAutore(),
			        nuovolibro.getQuantitaDisponibile(), nuovolibro.getGenere(), nuovolibro.getAnnoPubblicazione() };
			tableModel.addRow(obj1);
			
			try {
				obj= sel.fillTable();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			
//VERIFICARE---------------------------------------- + VEDI RIGA 49 E 50

				}
			
			
			//JList<Libro> list = new JList<>(nuovocatalogo.getLista_libri().toArray(new Libro[0]));
			//frame.getContentPane().add(list);
		
		});
		

		
		
		table.setBounds(10, 10, 427, 250);
		panel.add(table);
		tableModel = (DefaultTableModel) table.getModel();
		
		btn_new_libro.setBounds(215, 221, 96, 21);
		panel_1.add(btn_new_libro);
		
		
	}
}
