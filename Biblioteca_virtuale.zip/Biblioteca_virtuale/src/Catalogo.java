import java.util.List;

import Eccezioni.LibroNonTrovatoException;

public class Catalogo {
	private List<Libro> lista_libri;
	
	
	private void aggiungi_libro(Libro l) { //aggiungo un libro
		lista_libri.add(l);
	}
	
	private void rimuovi_libro(Libro l) { //tolgo un libro
		lista_libri.remove(l);
	}
	
	private Libro cerca_libro(String titolo) throws LibroNonTrovatoException { //ricerca per Titolo
		for(Libro l:lista_libri) {
			if(l.getTitolo().equals(titolo))
				return l;
		}
	    throw new LibroNonTrovatoException("Libro con il titolo : " + titolo + " non trovato");
	}
	
	//COSTRUTTORE
	public Catalogo(List<Libro> l) {
		this.lista_libri=l;
	}
}
