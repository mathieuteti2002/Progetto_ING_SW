import java.util.ArrayList;
import java.util.List;

public class Utente {
	/**
	 * @param username
	 * @param password
	 * @param email
	 * @param l_prenotati
	 */
	private String username;
	private String password;
	private String email;
	private List<Libro> l_prenotati; //lista dei libri presi dall'utente
	
	public void PrenotaLibro(Libro l) {
		l_prenotati.add(l);
	}
	
	//COSTRUTTORE
	public Utente(String username, String password, String email) {
		this.username = username;
		this.password = password;
		this.email = email;
		this.l_prenotati=new ArrayList<>(); //lista dei libri inizializzato a 0
	}

	
	
}
